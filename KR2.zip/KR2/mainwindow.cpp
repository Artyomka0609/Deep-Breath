#include "mainwindow.h"
#include "tickets.h"
#include "ui_mainwindow.h"

#include <QCloseEvent>
#include <QFileDialog>
#include <QFileInfo>
#include <QMessageBox>
#include <QTextDocument>

namespace {
const QString textFilter = QStringLiteral("Текстовые файлы (*.txt);;Все файлы (*)");
}

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->openTicketsButton, &QPushButton::clicked, this, &MainWindow::openSource);
    connect(ui->saveTicketsButton, &QPushButton::clicked, this, &MainWindow::saveTicketSource);
    connect(ui->analyzeTicketsButton, &QPushButton::clicked, this, &MainWindow::analyzeSource);
    connect(ui->exportReportButton, &QPushButton::clicked, this, &MainWindow::exportReport);
    connect(ui->sourceEdit, &QPlainTextEdit::textChanged, this, &MainWindow::invalidateTicketReport);
    connect(ui->queryEdit, &QLineEdit::textChanged, this, &MainWindow::invalidateTicketReport);
    connect(ui->sourceEdit->document(), &QTextDocument::modificationChanged, this, &QWidget::setWindowModified);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::invalidateTicketReport()
{
    ui->resultEdit->clear();
    ui->exportReportButton->setEnabled(false);
}

bool MainWindow::saveTicketSource()
{
    const QString text = ticketSourceText();
    const QString limitError = Tickets::sourceLimits(text);
    if (!limitError.isEmpty()) {
        QMessageBox::warning(this, tr("Исходный текст"), limitError);
        return false;
    }
    const QString path = QFileDialog::getSaveFileName(this, tr("Сохранить исходный текст"),
        ticketSourcePath.isEmpty() ? QStringLiteral("tickets.txt") : ticketSourcePath, textFilter);
    if (path.isEmpty())
        return false;
    const QString error = Tickets::writeUtf8(path, text);
    if (!error.isEmpty()) {
        QMessageBox::warning(this, tr("Ошибка записи"), error);
        return false;
    }
    ticketSourcePath = path;
    ui->ticketSourceLabel->setText(tr("Исходный текст — %1").arg(QFileInfo(path).fileName()));
    ui->sourceEdit->document()->setModified(false);
    return true;
}

QString MainWindow::ticketSourceText() const
{
    QString text = ui->sourceEdit->document()->toRawText();
    return text.replace(QChar::ParagraphSeparator, '\n');
}

bool MainWindow::confirmTicketChanges()
{
    if (!ui->sourceEdit->document()->isModified())
        return true;
    const auto action = QMessageBox::warning(this, tr("Несохранённый исходный текст"),
        tr("Сохранить изменения в обращениях?"),
        QMessageBox::Save | QMessageBox::Discard | QMessageBox::Cancel, QMessageBox::Cancel);
    if (action == QMessageBox::Save)
        return saveTicketSource();
    return action == QMessageBox::Discard;
}

void MainWindow::closeEvent(QCloseEvent *event)
{
    if (confirmTicketChanges())
        QMainWindow::closeEvent(event);
    else
        event->ignore();
}

void MainWindow::openSource()
{
    const QString path = QFileDialog::getOpenFileName(this, tr("Открыть обращения"), ticketSourcePath, textFilter);
    if (path.isEmpty() || !confirmTicketChanges())
        return;
    QString text;
    const QString error = Tickets::readSource(path, text);
    if (!error.isEmpty()) {
        QMessageBox::warning(this, tr("Ошибка открытия"), error);
        return;
    }
    ticketSourcePath = path;
    ui->sourceEdit->setPlainText(text);
    ui->sourceEdit->document()->setModified(false);
    ui->ticketSourceLabel->setText(tr("Исходный текст — %1").arg(QFileInfo(path).fileName()));
    invalidateTicketReport();
}

void MainWindow::analyzeSource()
{
    QString report;
    const QString error = Tickets::analyze(ticketSourceText(), ui->queryEdit->text(), report);
    if (!error.isEmpty()) {
        invalidateTicketReport();
        QMessageBox::warning(this, tr("Анализ обращений"), error);
        return;
    }
    ui->resultEdit->setPlainText(report);
    ui->exportReportButton->setEnabled(true);
}

void MainWindow::exportReport()
{
    const QString path = QFileDialog::getSaveFileName(this, tr("Экспортировать отчёт"), "report.txt", textFilter);
    if (path.isEmpty())
        return;
    if (!ticketSourcePath.isEmpty() && QFileInfo(path) == QFileInfo(ticketSourcePath)) {
        QMessageBox::warning(this, tr("Экспорт отчёта"), tr("Выберите для отчёта другой файл: здесь хранится исходный текст."));
        return;
    }
    QString report = ui->resultEdit->document()->toRawText();
    const QString error = Tickets::writeUtf8(path, report.replace(QChar::ParagraphSeparator, '\n'));
    if (!error.isEmpty())
        QMessageBox::warning(this, tr("Ошибка экспорта"), error);
}

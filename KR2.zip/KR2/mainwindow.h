#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui { class MainWindow; }
class QCloseEvent;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    void closeEvent(QCloseEvent *event) override;

private:
    void openSource();
    bool saveTicketSource();
    void analyzeSource();
    void exportReport();
    void invalidateTicketReport();
    QString ticketSourceText() const;
    bool confirmTicketChanges();

    Ui::MainWindow *ui;
    QString ticketSourcePath;
};

#endif

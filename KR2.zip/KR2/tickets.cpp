#include "tickets.h"

#include <QFile>
#include <QRegularExpression>
#include <QSaveFile>
#include <QStringConverter>
#include <QStringList>
#include <QTextStream>

namespace {
constexpr int maxBytes = 2097152;
constexpr int maxRecords = 10000;
const QString sizeError = QStringLiteral("Размер исходного текста превышает 2 МиБ (2097152 байта).");

QString parseTicket(const QString &line, QStringList &fields)
{
    static const QRegularExpression numberRe(QStringLiteral(R"(\A[1-9][0-9]{2}\z)"));
    static const QRegularExpression emailRe(
        QStringLiteral(R"(\A[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\z)"));

    fields = line.split(';', Qt::KeepEmptyParts);
    if (fields.size() != 3)
        return QStringLiteral("Ожидалось три поля");
    for (QString &field : fields)
        field = field.trimmed();

    if (!numberRe.match(fields[0]).hasMatch())
        return QStringLiteral("Номер должен быть от 100 до 999");
    if (fields[1].size() < 6 || fields[1].size() > 254 || !emailRe.match(fields[1]).hasMatch())
        return QStringLiteral("Неверный email");
    if (fields[2].isEmpty() || fields[2].size() > 500)
        return QStringLiteral("Длина описания должна быть от 1 до 500 единиц UTF-16");
    return {};
}

QString listText(const QStringList &values)
{
    return values.isEmpty() ? QStringLiteral("Нет") : values.join('\n');
}
}

namespace Tickets {
QString sourceLimits(QString source)
{
    if (source.size() > maxBytes || source.toUtf8().size() > maxBytes)
        return sizeError;

    QTextStream lines(&source, QIODevice::ReadOnly);
    int records = 0;
    while (!lines.atEnd()) {
        if (!lines.readLine().trimmed().isEmpty() && ++records > maxRecords)
            return QStringLiteral("В исходном тексте больше 10000 непустых строк.");
    }
    return {};
}

QString analyze(QString source, const QString &query, QString &report)
{
    report.clear();
    const QString limitError = sourceLimits(source);
    if (!limitError.isEmpty())
        return limitError;
    const QString needle = query.trimmed();
    if (needle.size() > 100)
        return QStringLiteral("Запрос длиннее 100 единиц UTF-16 после удаления внешних пробелов.");

    QStringList emails, errors, matches;
    int lineNumber = 0;
    QTextStream input(&source, QIODevice::ReadOnly);
    while (!input.atEnd()) {
        const QString line = input.readLine();
        ++lineNumber;
        if (line.trimmed().isEmpty())
            continue;
        QStringList fields;
        const QString error = parseTicket(line, fields);
        if (!error.isEmpty()) {
            errors << QStringLiteral("Строка %1: %2").arg(lineNumber).arg(error);
            continue;
        }
        emails << fields[1];
        if (!needle.isEmpty() && fields[2].contains(needle, Qt::CaseInsensitive))
            matches << fields.join(';');
    }

    const QStringList sections = {
        QStringLiteral("Непустых строк: %1").arg(emails.size() + errors.size()),
        QStringLiteral("Корректных записей: %1").arg(emails.size()),
        QStringLiteral("Ошибочных записей: %1").arg(errors.size()),
        needle.isEmpty() ? QStringLiteral("Поиск не задан") : QStringLiteral("Запрос: %1").arg(needle),
        QStringLiteral("Совпадений: %1").arg(matches.size()), {},
        QStringLiteral("Найденные обращения"), listText(matches), {},
        QStringLiteral("Email всех корректных записей"), listText(emails), {},
        QStringLiteral("Ошибки"), listText(errors)
    };
    report = sections.join('\n');
    return {};
}

QString readSource(const QString &path, QString &source)
{
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly))
        return file.errorString();
    if (file.size() > maxBytes)
        return sizeError;
    const QByteArray bytes = file.read(maxBytes + 1);
    if (file.error() != QFileDevice::NoError)
        return file.errorString();
    if (bytes.size() > maxBytes)
        return sizeError;
    QStringDecoder decoder(QStringDecoder::Utf8, QStringConverter::Flag::Stateless);
    QString decoded = decoder.decode(bytes);
    const bool invalid = decoder.hasError();
    if (invalid)
        return QStringLiteral("Файл должен содержать текст в кодировке UTF-8.");
    decoded.replace("\r\n", "\n").replace('\r', '\n');
    const QString error = sourceLimits(decoded);
    if (error.isEmpty())
        source = decoded;
    return error;
}

QString writeUtf8(const QString &path, const QString &text)
{
    QSaveFile file(path);
    if (!file.open(QIODevice::WriteOnly))
        return file.errorString();
    QTextStream out(&file);
    out.setEncoding(QStringConverter::Utf8);
    out << text;
    out.flush();
    if (out.status() != QTextStream::Ok) {
        file.cancelWriting();
        return QStringLiteral("Не удалось полностью записать текст.");
    }
    return file.commit() ? QString() : file.errorString();
}
}

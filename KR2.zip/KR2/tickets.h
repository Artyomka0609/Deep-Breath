#ifndef TICKETS_H
#define TICKETS_H

#include <QString>

namespace Tickets {

QString sourceLimits(QString source);
QString analyze(QString source, const QString &query, QString &report);
QString readSource(const QString &path, QString &source);
QString writeUtf8(const QString &path, const QString &text);
}

#endif

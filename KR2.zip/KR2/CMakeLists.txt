cmake_minimum_required(VERSION 3.16)
project(KR2 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTOMOC ON)

find_package(Qt6 6.2 REQUIRED COMPONENTS Widgets)
qt_add_executable(KR2
    main.cpp
    mainwindow.h mainwindow.cpp mainwindow.ui
    tickets.h tickets.cpp
)
target_link_libraries(KR2 PRIVATE Qt6::Widgets)
set_target_properties(KR2 PROPERTIES WIN32_EXECUTABLE TRUE)
if(MSVC)
    target_compile_options(KR2 PRIVATE /utf-8)
endif()
